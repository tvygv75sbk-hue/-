# -*- coding: utf-8 -*-
import subprocess, sys, os

ROOT = os.path.dirname(__file__)
PY = sys.executable  # 使用当前解释器，避免 Windows 上 "python" 解析失败

# 构造绝对路径，避免非 ASCII 路径导致的问题
p = lambda *parts: os.path.join(ROOT, *parts)

steps = [
    [PY, p('src','data_collection','fetch_open_meteo.py')],
    [PY, p('src','data_collection','fetch_wikimedia.py')],
    [PY, p('src','data_collection','fetch_trends.py')],
    [PY, p('src','data_collection','build_target_from_signals.py')],
    [PY, p('src','preprocessing','cleaning.py')],
    [PY, p('src','feature_engineering','feature_builder.py')],
    [PY, p('src','models','train_baselines.py')],
    [PY, p('src','visualization','visualizer.py')],
]

# 可选：入库（需要先执行 database/create_tables.sql，并设置环境变量 MYSQL_URL）
if os.environ.get('MYSQL_URL'):
    steps.append([PY, p('src','database','load_to_mysql.py')])
else:
    print('Skip MySQL load: env MYSQL_URL not set')

for cmd in steps:
    print('>>', ' '.join(cmd))
    r = subprocess.run(cmd)  # 已使用绝对路径，无需 cwd
    if r.returncode != 0:
        print('Step failed:', ' '.join(cmd))
        sys.exit(r.returncode)

print('Pipeline finished. See reports/ and data/ directories.')
